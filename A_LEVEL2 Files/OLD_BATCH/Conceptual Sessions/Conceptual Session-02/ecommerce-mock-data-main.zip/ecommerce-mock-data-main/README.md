# How To Use The Mock Data

The **ObjectID** are already there in the json data as 
`"_id":  {"$oid":  "6550a93fea0371cbab511705"},`
You just have to import the dataset directly on your **MongoDB Compass / Atlas**




